import React from "react";
export default function Signout(){
    return(
        <div>Signout</div>
    );
}