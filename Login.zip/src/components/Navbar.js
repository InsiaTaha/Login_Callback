import React,{useState} from "react";
import "./NavbarStyle.css";
import Layout from './Layout';
import Signup from './Signup';
import Signout from './Signout';
import { BrowserRouter , Route, Routes } from "react-router-dom";

export default function App() {
  const [userNameLogin,setUserLogin] = useState('')
  function Listener(data) {
    
    setUserLogin(data.userName);
    console.log(userNameLogin)
  }
  return (
   
    <BrowserRouter>
     <div className="Nav">
    <Routes>
      <Route path="/" element={<Layout />}>
        {/* <Route index element={<Login TokenUser={(data) => Listener(data)}/>} /> */}
        <Route path="/Signup" element={<Signup/>} />
      </Route>
      
    </Routes>
    </div>
    {console.log(userNameLogin)}
  </BrowserRouter>
 
 
  );
}


