import React,{useState}  from 'react';
import { useMutation } from 'react-query';
import axios from 'axios';
import { QueryClient, QueryClientProvider, useQuery } from 'react-query'
import './Signinstyle.css'

function Signup() {
    const queryClient = new QueryClient()
  return(
    <QueryClientProvider client={queryClient}>
         <SignupMustate />
       </QueryClientProvider>
       )
  }
function SignupMustate() {  
    const mutation = useMutation(
        newUserRecord => {
          return axios.post('http://localhost:3000/UserRecord', newUserRecord)
        }
      )
      const [FName, setFName] = useState();
      const [LName, setLName] = useState();
      const [UName, setUName] = useState();
      const [Password, setPassword] = useState();
    // const [Data,setData] = useState({
    //     FName:"",
    //     LName:"",
    //     UName:"",
    //     Password:""
    // })
    // function handleChange(evt) {
    //     evt.preventDefault();
    //     setData({
    //         ...Data,
    //         [evt.target.name]: evt.target.value
    //       });
    //       console.log(Data);
    //   }
      
    //   const [storeData, setStoreData] = useState([]);
    //   //Ok Button functionality
    //   const handleSubmit = (e) => {
    //     e.preventDefault();
    //     setStoreData([...storeData, Data]);
    //     console.log(storeData)
    //     // mutation.mutate({ id: new Date(), storeData})
    //   };
    return(
      <div className="form">
          <div className="form-body">
            <h1>Sign up </h1>
              <div className="username">
                  <label className="form__label">First Name </label>
                  <input
        type='text'
        name='FName'
        value={FName}
        placeholder="First Name"  
        onChange={e => setFName(e.target.value)} 
        />
              </div>
              <div className="lastname">
                  <label className="form__label">Last Name </label>
                  <input  type="text" name="LName" id="lastName"  className="form__input"placeholder="Last Name"  
                  value={LName}
                  onChange={e => setLName(e.target.value)} />
              </div>
              <div className="email">
                  <label className="form__label">User Name </label>
                  <input  type="text" name="UName" className="form__input" placeholder="User Name"  
                  value={UName}
                  onChange={e => setUName(e.target.value)} />
              </div>
              <div className="password">
                  <label className="form__label">Password </label>
                  <input className="form__input" type="password"  name="Password" placeholder="Password" 
                   value={Password}
                   onChange={e => setPassword(e.target.value)} />
              </div>
          </div>
          <div className="footer">
          {mutation.isLoading ? (
          'Please Wait!...'
        ) : (
          <>
            {mutation.isError ? (
              <div>An error occurred: {mutation.error.message}</div>
            ) : null}
  
            {mutation.isSuccess ? <div>User Added Sucessfully!</div> : null}
  
            <button
              onClick={() => {
                mutation.mutate({FName,LName,UName,Password})
              }}
            >
              Signup
            </button>
            {/* <button type="submit"  onClick={handleSubmit} className="btn">Ok</button> */}
          </>
        )}
              
          </div>
      </div>      
    );     
}
export default Signup;