import { useState, useEffect, useContext } from "react";
import axios from 'axios';
import { QueryClient, QueryClientProvider, useQuery } from 'react-query'
import { useMutation } from 'react-query';
import Navbar from'./Navbar'



function Login() {
    
    const queryClient = new QueryClient();
    const [userName,setUserName] = useState('');
    const [FirstName,setFirstName] = useState('');
    const [LastName,setLastName] = useState('');
 

  
    function showData() {
      
      if (userName) {
        return( 
          <>
          <div className="Dashboard">
          <h1>You are Loggged in!</h1>
          <h3>Welcome {FirstName} {LastName} </h3>
          <h4>Your UserID is {userName}</h4>
          <p className="space"></p>
          <button onClick={onLogoutClicked}>Logout</button>
          </div>
          </>)
      }
      else {
        
        return(<QueryClientProvider client={queryClient}>
   
         <LoginMutate getUserName={(data)=>Listener(data)}/>
       </QueryClientProvider>)
      }
    }
  
    function onLogoutClicked() {
      setUserName('');
    }

    function Listener(data) {
      setFirstName(data.FName);
      setLastName(data.LName);
      setUserName(data.UName);
    }

     
    

  return(<>
       <Navbar/>
         {showData()}</>
       )
  }
export const LoginMutate = ({getUserName}) => {
  const [user, setUser] = useState("");
  const [pwd, setPwd] = useState("");
  const [errMsg, setErrMsg] = useState("");
  const [success, setSuccess] = useState(false);

  const mutation = useMutation(
    newUserRecord => {
       return axios.get('http://localhost:3000/UserRecord?UName='+user+'&Password='+pwd).then((resp) => { 
        if(resp.data[0] != null)
        {
          setSuccess(true);
          getUserName(resp.data[0])
        }
        else{
          alert("Please Enter a Valid Username and Password");
        }
      });
    }
  )

 
  return (
    <>
      {success ? (
        <section>
          <h1></h1>
          <br />
          <p>{/* <a href="#">Go to Home</a> */}</p>
        </section>
      ) : (
        <section>
          <p
            //ref={errRef}
            className={errMsg ? "errmsg" : "offscreen"}
            aria-live="assertive"
          >
            {errMsg}
          </p>
          <h1>Sign In</h1>
          <form>
            <label htmlFor="username">Username:</label>
            <input
              type="text"
              id="username"
              //ref={userRef}
              autoComplete="off"
              onChange={(e) => setUser(e.target.value)}
              value={user}
              required
            />
            <p className="space"></p>
            <label htmlFor="password">Password:</label>
            <input
              type="password"
              id="password"
              onChange={(e) => setPwd(e.target.value)}
              value={pwd}
              required
            />
             <p className="space"></p>
               <div className="footer">
          {mutation.isLoading ? (
          'Please Wait!...'
        ) : (
          <>
            {mutation.isError ? (
              <div>An error occurred: {mutation.error.message}</div>
            ) : null}
  
            {mutation.isSuccess ? <div>Login SucessFull</div> : null}
  
            <button
              onClick={() => {
                mutation.mutate()
              }}
            >
              Login
            </button>
            {/* <button type="submit"  onClick={handleSubmit} className="btn">Ok</button> */}
          </>
        )}
              
          </div>
          <p>
          </p>
          </form>
         
        </section>
      )}
    </>
  );
      }

export default Login;
